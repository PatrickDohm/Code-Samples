
/* AtoDRPMLCD2  October 4, 2019
   
	 The System Clock is running at 32 MHz.  
*/

#include "main.h"
#include "stm32L031.h"

const char ASCII [] = "0123456789";
void ConfigureUSART(unsigned int baudDivisor);
void USARTPutChar(char ch);
void SendMsg(const char msg[]);
void SystemClock_Config(void);
void ConvertRPM2String(int f, char s[]);
void ConvertDuty2String(int f, char p[]);
extern void assembly();//sets GPIOA_MODER = 0xEBFEFCFF;
int main(void)
{
   SystemClock_Config();
   int i, j, tmp;
   int freq;  
	 int RPM;
	 
   char s[10];
	char p[10];
   RCC_IOPENR |= 1;         //Bit 1 is GPIOA clock enable bit 
   RCC_APB2ENR |= 0x200;     //Bit 9 is ADC 1 clock enable bit
   RCC_APB1ENR |= 1;         //Enable peripheral timer for timer 2 (bit 0)
   //PWM set up for output bit
	 assembly();//Bits 17-16 = 02 for Alternate function on PA8  
   //OTYPER register resets to 0 so it is push/pull by default
   GPIOA_OSPEEDER |= 0x30000;  //Bits 17-16 = 11 for high speed 
	 //PUPDR defaults to no pull up no pull down    
   //Timer 2 bits
   GPIOA_AFRH |= 0x00000005; //Sets PA8 to Timer 2, this will make the pwm come out of pa8 so thats where the LED is connected
	 GPIOA_MODER |= 0x0F;      //PA1 and PA0 is analog
   GPIOA_PUPDR &= 0xFFFFFFCF; //Pin PA1 has no pull up and no pull down
   TIM2_CCMR1 |= 0x60;      //Timer 2 in PWM Mode bits 6,5,4 = 110
   TIM2_CCMR1 |= 0x0C;      //Timer  Preload enable and fast enable
   TIM2_CR1 |= (1 << 7);    //Auto reload is buffered 
   TIM2_PSC = 7999;         //Prescaling by 8000
   TIM2_ARR = 200;          //(((32 MHz)/200)/8000 = 20 Hz
   TIM2_CCR1 = 1000;        //Duty cycle starts at 50%
   TIM2_CCER |= 1;          //Compare and capture output enable
   TIM2_EGR |= 1;           //Enable event
   TIM2_CR1 |= 1;           //Enable Timer 2
   //Set up UART
   RCC_APB1ENR |= (1 << 17);  //Enable USART2 
   //UART PIN Bits
   GPIOA_AFRH |= 0x0440;  //Alternate Func PA9 PA10 to USART2
   GPIOA_MODER |= (1 << 21);GPIOA_MODER &= ~(1 << 20);    
	 GPIOA_MODER |= (1 << 19);GPIOA_MODER &= ~(1 << 18);  //Bits 21, 20, 19, 18 = 1010 for Alt Func PA9, PA10
   //OTYPER register resets to 0 so it is push/pull by default
   GPIOA_OSPEEDER |= 0x3C0000;  //Bits 21 to 19 = 11 for high speed on PA9 PA10
   //PUPDR defaults to no pull up no pull down    
   //The over8 bit in CR1 = 0 so BRR = fclk/TxBaud
	 //If fclk = 32MHz and TxBaud = 4800 
	 //BRR = 32000000/4800 = 6667
    ConfigureUSART(6667);
//Analog out set up on PA1 and PA0
   ADC1_ISR |= 1;  //Clear ADRDY bit in ADC_ISR
   ADC1_CR |= 1;   //Set ADEN = 1 in ADC_CR to enable ADC 
   ADC1_CHSELR = 2;         //Select Channel 1 
	 ADC1_SMPR = 7;            //Sample time register
	 while(1)
     {ADC1_CHSELR =2;//select channel 1
			 ADC1_CR |= 0x4;   // Bit 2 does software start of A/D conversion
			while((ADC1_ISR & 0x4) == 0); //Bit 2 is End of Conversion
      TIM2_ARR = ADC1_DR & 0xFFF;
      
      freq = (int)(4000.0/TIM2_ARR);
			RPM=freq*60; //conversion of frequency to RPM
      ConvertRPM2String(RPM, s);
      SendMsg(s);	//writes RPM to screen
			for(i=0;i<30000;i++)
					for(j=0;j<100;j++);
			ADC1_ISR |=1;
			ADC1_CR |= 1;
			 
			 ADC1_CHSELR=1;//Select channel 0
			 ADC1_CR |= 0x4;//bit 2 does software start of A/D conversion
			 while((ADC1_ISR & 0x4)==0);//bit 2 is end of conversion
			 TIM2_CCR1=(ADC1_DR/4095)*TIM2_ARR/5;   //sets the duty cycle, its dived by 5 so the max is 20%
			ConvertDuty2String((TIM2_CCR1/TIM2_ARR)*100,p);	//makes the duty cycle into a string
			SendMsg(p);	//Sends the duty cycle to LCD
      for(i=0;i<30000;i++)
         for(j=0;j<100;j++);
			ADC1_ISR |= 1;
			ADC1_CR |= 1;
     }
   }

void ConvertRPM2String(int f, char s[])
{
  char d0, d1, d2, d3;
  d0 = f%10;
  f = f/10;
  d1 = f%10;
  f = f/10;
  d2 = f%10;
  f = f/10;
  d3 = f%10;
  s[0] = '/';
  s[1] = ' ';
  s[2] = ASCII[d3];
  s[3] = ASCII[d2];
  s[4] = ASCII[d1];
  s[5] = ASCII[d0];
  s[6] = 'R';
  s[7] = 'P';
  s[8] = 'M';
  s[9] = '\0';
}
void ConvertDuty2String(int f, char p[]){
	char d0, d1, d2, d3;
  d0 = f%10;
  f = f/10;
  d1 = f%10;
  f = f/10;
  d2 = f%10;
  f = f/10;
  d3 = f%10;
  p[0] = ' ';
  p[1] = ' ';
  p[2] = ASCII[d3];
  p[3] = ASCII[d2];
  p[4] = ASCII[d1];
  p[5] = ASCII[d0];
  p[6] = '%';
  p[7] = ' ';
  p[8] = ' ';
  p[9] = '\0';
}

//
void ConfigureUSART(unsigned int baudDivisor)
  {USART2_CR1 = 0;            //Disable during set up. Wd len = 8, Parity = off
   USART2_BRR = baudDivisor;  //Set up baud rate
   USART2_CR2 = 0;            //1 stop bit
   USART2_CR1 = 0x0D;
   USART2_CR3 = 0;            //Disable interrupts and DMA
  }
//
void USARTPutChar(char ch)
  {//Wait for empty flag
    while((USART2_ISR & 0x80) == 0);
   USART2_TDR = ch;
  }
void SendMsg(const char msg[])
  {int i = 0;
   while(msg[i] != 0)
      {USARTPutChar(msg[i]);
       i++;
      }
  }    

//Sets clock to 32 MHz
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage 
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLLMUL_4;
  RCC_OscInitStruct.PLL.PLLDIV = RCC_PLLDIV_2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

void Error_Handler(void)
{
}

