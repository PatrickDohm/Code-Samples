//Created: July 7, 2019
//GPIO Port A Addresses
#define GPIOA_MODER    (*((volatile unsigned long *) 0x50000000))   //GPIO A Mode Reg
#define GPIOA_PUPDR    (*((volatile unsigned long *) 0x5000000C))   //GPIO A Pull Up/Pull Dn Reg
#define GPIOA_OSPEEDER (*((volatile unsigned long *) 0x50000008))   //GPIO A Speed register
#define GPIOA_OTYPER   (*((volatile unsigned long *) 0x50000004))   //GPIO A Output type register
#define GPIOA_IDR      (*((volatile unsigned long *) 0x50000010))   //GPIO A Input Data register
#define GPIOA_ODR      (*((volatile unsigned long *) 0x50000014))   //GPIO A Output Data register
#define GPIOA_BSRR     (*((volatile unsigned long *) 0x50000018))   //GPIO A Output Bit set/reset reg
#define GPIOA_AFRL     (*((volatile unsigned long *) 0x50000020))   //GPIO A Alt Funct reg bits 0-7
#define GPIOA_AFRH     (*((volatile unsigned long *) 0x50000024))   //GPIO A Alt Funct reg bits 8-15
//GPIO Port B Addresses
#define GPIOB_MODER    (*((volatile unsigned long *) 0x50000400))   //GPIO B Mode Reg
#define GPIOB_PUPDR    (*((volatile unsigned long *) 0x5000040C))   //GPIO B Pull Up/Pull Dn Reg
#define GPIOB_OSPEEDER (*((volatile unsigned long *) 0x50000408))   //GPIO B Speed register
#define GPIOB_OTYPER   (*((volatile unsigned long *) 0x50000404))   //GPIO B Output type register
#define GPIOB_IDR      (*((volatile unsigned long *) 0x50000410))   //GPIO B Input Data register
#define GPIOB_ODR      (*((volatile unsigned long *) 0x50000414))   //GPIO B Output Data register
#define GPIOB_BSRR     (*((volatile unsigned long *) 0x50000418))   //GPIO B Output Bit set/reset reg
#define GPIOB_AFRL     (*((volatile unsigned long *) 0x50000420))   //GPIO B Alt Funct reg bits 0-7
#define GPIOB_AFRH     (*((volatile unsigned long *) 0x50000424))   //GPIO B Alt Funct reg bits 8-15

//Clock addresses
#define RCC_CR      (*((volatile unsigned long *) 0x40021000))   //Clock Control Register
#define RCC_ICSCR   (*((volatile unsigned long *) 0x40021004))   //Clock Calibration Register
#define RCC_CFGR    (*((volatile unsigned long *) 0x4002100C))   //Clock Config Register
#define RCC_CIER     (*((volatile unsigned long *) 0x40021010))   //Clock Interrupt Register
#define RCC_CIFR     (*((volatile unsigned long *) 0x40021014))   //Clock Int Flag Register
#define RCC_CICR     (*((volatile unsigned long *) 0x40021018))   //Clock Int Clear Reg
#define RCC_IOPRSTR  (*((volatile unsigned long *) 0x4002101C))   //Clock GPIO Reset Reg

#define RCC_AHBRSTR (*((volatile unsigned long *) 0x40021020))   //Periph Reset Register
#define RCC_APB2RSTR (*((volatile unsigned long *) 0x40021024))  //Periph Reset Reg
#define RCC_APB1RSTR (*((volatile unsigned long *) 0x40021028))  //Periph Reset Reg
#define RCC_IOPENR (*((volatile unsigned long *) 0x4002102C))   //GPIO Enable Reg
#define RCC_AHBENR (*((volatile unsigned long *) 0x40021030))   //Periph Clock Enable Reg
#define RCC_APB2ENR (*((volatile unsigned long *) 0x40021034))   //Periph Clock Reg
#define RCC_APB1ENR (*((volatile unsigned long *) 0x40021038))   //Periph Clock Reg
#define RCC_IOPSMENR (*((volatile unsigned long *) 0x4002103C))   //Clk En Sleep Mode Reg
#define RCC_AHBSMENR (*((volatile unsigned long *) 0x40021040))   //Clk En Sleep Mode Reg
#define RCC_APB2SMENR (*((volatile unsigned long *) 0x40021044))   //Clk En Sleep Mode Reg
#define RCC_APB1SMENR (*((volatile unsigned long *) 0x40021048))   //Clk En Sleep Mode Reg
#define RCC_CCIPR (*((volatile unsigned long *) 0x4002104C))   //Clk Configuration Reg
#define RCC_CSR (*((volatile unsigned long *) 0x40021050))   //Clk Control Status Reg

//Flash Memory
#define FLASH_ACR (*((volatile unsigned long *) 0x40022000))   //Flash Access Control Register

//A to D Addresses
//ADC1
#define ADC1_ISR (*((volatile unsigned long *) 0x40012400))      //ADC1 Status Register
#define ADC1_IER (*((volatile unsigned long *) 0x40012404))     //ADC1 Int Enable Reg
#define ADC1_CR (*((volatile unsigned long *) 0x40012408))     //ADC1 Control Register 
#define ADC1_CFGR1 (*((volatile unsigned long *) 0x4001240C))   //ADC1 Config Reg 2
#define ADC1_CFGR2 (*((volatile unsigned long *) 0x40012410))   //ADC1 Config Reg 1
#define ADC1_DR (*((volatile unsigned long *) 0x40012440))      //ADC1 Data Register
#define ADC1_CHSELR (*((volatile unsigned long *) 0x40012428))  //ADC1 Channel Select Reg
#define ADC1_SMPR (*((volatile unsigned long *) 0x40012414))    //ADC1 Sample time Reg
//ADC Common
#define ADC_CCR (*((volatile unsigned long *) 0x40012708))     //ADC Common Control Register
//Timer 2 addresses
#define TIM2_CR1  (*((volatile unsigned long *) 0x40000000))   //Timer 2 Control Reg 1
#define TIM2_CR2  (*((volatile unsigned long *) 0x40000004))   //Timer 2 Control Reg 2
#define TIM2_SR   (*((volatile unsigned long *) 0x40000010))   //Timer 2 Status Reg
#define TIM2_DIER (*((volatile unsigned long *) 0x4000000C))   //Timer 2 Interrupt Enable
#define TIM2_EGR  (*((volatile unsigned long *) 0x40000014))   //Timer 2 Event Generation Reg
#define TIM2_CCMR1 (*((volatile unsigned long *) 0x40000018))   //Timer 2 Capture/Compare Mode
#define TIM2_CCER (*((volatile unsigned long *) 0x40000020))   //Timer 2 Compare/Capture Reg
#define TIM2_CNT  (*((volatile unsigned long *) 0x40000024))   //Timer 2 Count Reg
#define TIM2_PSC  (*((volatile unsigned long *) 0x40000028))   //Timer 2 Prescale Reg
#define TIM2_ARR  (*((volatile unsigned long *) 0x4000002C))   //Timer 2 Auto-Reload Reg
#define TIM2_CCR1 (*((volatile unsigned long *) 0x40000034))   //Timer 2 Capture/Compare Reg
//Timer 21 addresses
#define TIM21_CR1  (*((volatile unsigned long *) 0x40010800))   //Timer 2 Control Reg 1
#define TIM21_CR2  (*((volatile unsigned long *) 0x40010804))   //Timer 2 Control Reg 2
#define TIM21_SR   (*((volatile unsigned long *) 0x40010810))   //Timer 2 Status Reg
#define TIM21_DIER (*((volatile unsigned long *) 0x4001080C))   //Timer 2 Interrupt Enable
#define TIM21_EGR  (*((volatile unsigned long *) 0x40010814))   //Timer 2 Event Generation Reg
#define TIM21_CCMR1 (*((volatile unsigned long *) 0x40010818))   //Timer 2 Capture/Compare Mode
#define TIM21_CCER (*((volatile unsigned long *) 0x40010820))   //Timer 2 Compare/Capture Reg
#define TIM21_CNT  (*((volatile unsigned long *) 0x40010824))   //Timer 2 Count Reg
#define TIM21_PSC  (*((volatile unsigned long *) 0x40010828))   //Timer 2 Prescale Reg
#define TIM21_ARR  (*((volatile unsigned long *) 0x4001082C))   //Timer 2 Auto-Reload Reg
#define TIM21_CCR1 (*((volatile unsigned long *) 0x40010834))   //Timer 2 Capture/Compare Reg
//Timer 22 addresses
#define TIM22_CR1  (*((volatile unsigned long *) 0x40011400))   //Timer 2 Control Reg 1
#define TIM22_CR2  (*((volatile unsigned long *) 0x40011404))   //Timer 2 Control Reg 2
#define TIM22_SR   (*((volatile unsigned long *) 0x40011410))   //Timer 2 Status Reg
#define TIM22_DIER (*((volatile unsigned long *) 0x4001140C))   //Timer 2 Interrupt Enable
#define TIM22_EGR  (*((volatile unsigned long *) 0x40011414))   //Timer 2 Event Generation Reg
#define TIM22_CCMR1 (*((volatile unsigned long *) 0x40011418))   //Timer 2 Capture/Compare Mode
#define TIM22_CCER (*((volatile unsigned long *) 0x40011420))   //Timer 2 Compare/Capture Reg
#define TIM22_CNT  (*((volatile unsigned long *) 0x40011424))   //Timer 2 Count Reg
#define TIM22_PSC  (*((volatile unsigned long *) 0x40011428))   //Timer 2 Prescale Reg
#define TIM22_ARR  (*((volatile unsigned long *) 0x4001142C))   //Timer 2 Auto-Reload Reg
#define TIM22_CCR1 (*((volatile unsigned long *) 0x40011434))   //Timer 2 Capture/Compare Reg

//Timer 3 addresses
#define TIM3_CR1  (*((volatile unsigned long *) 0x40000400))   //Timer 3 Control Reg 1
#define TIM3_CR2  (*((volatile unsigned long *) 0x40000404))   //Timer 3 Control Reg 2
#define TIM3_SR   (*((volatile unsigned long *) 0x40000410))   //Timer 3 Status Reg
#define TIM3_DIER (*((volatile unsigned long *) 0x4000040C))   //Timer 3 Interrupt Enable
#define TIM3_EGR  (*((volatile unsigned long *) 0x40000414))   //Timer 3 Event Generation Reg
#define TIM3_CCMR1 (*((volatile unsigned long *) 0x40000418))   //Timer 3 Capture/Compare Mode
#define TIM3_CCER (*((volatile unsigned long *) 0x40000420))   //Timer 3 Compare/Capture Reg
#define TIM3_CNT  (*((volatile unsigned long *) 0x40000424))   //Timer 3 Count Reg
#define TIM3_PSC  (*((volatile unsigned long *) 0x40000428))   //Timer 3 Prescale Reg
#define TIM3_ARR  (*((volatile unsigned long *) 0x4000042C))   //Timer 3 Auto-Reload Reg
#define TIM3_CCR1 (*((volatile unsigned long *) 0x40000434))   //Timer 3 Capture/Compare Reg
//Timer 6 addresses
#define TIM6_CR1 (*((volatile unsigned long *) 0x40001000))   //Timer 6 Control Reg 1
#define TIM6_CR2 (*((volatile unsigned long *) 0x40001004))   //Timer 6 Control Reg 2
#define TIM6_SR (*((volatile unsigned long *) 0x40001010))    //Timer 6 Status Reg
#define TIM6_DIER (*((volatile unsigned long *) 0x4000100C))  //Timer 6 Interrupt Enable
#define TIM6_CNT (*((volatile unsigned long *) 0x40001024))   //Timer 6 Count Reg
#define TIM6_PSC (*((volatile unsigned long *) 0x40001028))   //Timer 6 Prescale Reg
#define TIM6_ARR (*((volatile unsigned long *) 0x4000102C))   //Timer 6 Auto-Reload Reg
#define TIM6_EGR (*((volatile unsigned long *) 0x40001014))   //Timer 6 Event Generation Reg
//Interrupt controller addresses
#define NVICISER0 (*((volatile unsigned long *) 0xE000E100))   //Interrupt Enable 0-31
#define NVICISER1 (*((volatile unsigned long *) 0xE000E104))   //Interrupt Enable 32-63
#define NVICICER0 (*((volatile unsigned long *) 0xE000E180))   //Interrupt Clear Enable 0-31
#define NVICICER1 (*((volatile unsigned long *) 0xE000E184))   //Interrupt Clear Enable 32-63
//USART2 Registers
#define USART2_CR1  (*((volatile unsigned long *) 0x40004400))  //USART2 Control Register 1
#define USART2_CR2  (*((volatile unsigned long *) 0x40004404))  //USART2 Control Register 2
#define USART2_CR3  (*((volatile unsigned long *) 0x40004408))  //USART2 Control Register 3
#define USART2_BRR  (*((volatile unsigned long *) 0x4000440C))  //USART2 Baud Rate Register
#define USART2_GTPR (*((volatile unsigned long *) 0x40004410))  //USART2 Gd Time & Prescale Register
#define USART2_RTOR (*((volatile unsigned long *) 0x40004414))  //USART2 Rec Timeout Register
#define USART2_RQR (*((volatile unsigned long *) 0x40004418))   //USART2 Request Register
#define USART2_ISR (*((volatile unsigned long *) 0x4000441C))   //USART2 Int Status Register
#define USART2_ICR (*((volatile unsigned long *) 0x40004420))   //USART2 Int Flag Clear Register
#define USART2_RDR (*((volatile unsigned long *) 0x40004424))   //USART2 Rec Data Register
#define USART2_TDR (*((volatile unsigned long *) 0x40004428))   //USART2 Trans Data Register

//LPUART Registers
#define LPUART1_CR1  (*((volatile unsigned long *) 0x40004800))  //LPUART 1 Control Register 1
#define LPUART1_CR2  (*((volatile unsigned long *) 0x40004804))  //LPUART 1 Control Register 2
#define LPUART1_CR3  (*((volatile unsigned long *) 0x40004808))  //LPUART 1 Control Register 3
#define LPUART1_BRR  (*((volatile unsigned long *) 0x4000480C))  //LPUART 1 Baud Rate Register
#define LPUART1_RQR  (*((volatile unsigned long *) 0x40004818))  //LPUART 1 Request Register
#define LPUART1_ISR  (*((volatile unsigned long *) 0x4000481C))  //LPUART 1 Int Status Register
#define LPUART1_ICR  (*((volatile unsigned long *) 0x40004820))  //LPUART 1 Int Flag Clear Register
#define LPUART1_RDR  (*((volatile unsigned long *) 0x40004824))  //LPUART 1 Receive Data Register
#define LPUART1_TDR  (*((volatile unsigned long *) 0x40004828))  //LPUART 1 Transmit Data Register

//I2C1
#define I2C1_CR1   (*((volatile unsigned long *) 0x40005400)) //I2C1 Control Reg 1
#define I2C1_CR2   (*((volatile unsigned long *) 0x40005404)) //I2C1 Control Reg 2
#define I2C1_OAR1  (*((volatile unsigned long *) 0x40005408)) //I2C1 Own Addr Reg 1
#define I2C1_OAR2  (*((volatile unsigned long *) 0x4000540C)) //I2C1 Own Addr Reg 2
#define I2C1_DR    (*((volatile unsigned long *) 0x40005410)) //I2C1 Data Reg
#define I2C1_SR1   (*((volatile unsigned long *) 0x40005414)) //I2C1 Status Reg 1
#define I2C1_SR2   (*((volatile unsigned long *) 0x40005418)) //I2C1 Status Reg 2
#define I2C1_CCR   (*((volatile unsigned long *) 0x4000541C)) //I2C1 Clock Control Reg
#define I2C1_TRISE (*((volatile unsigned long *) 0x40005420)) //I2C1 Rise Time Reg
#define I2C1_FLTR  (*((volatile unsigned long *) 0x40005424)) //I2C1 Filter Reg
//I2C2
#define I2C2_CR1   (*((volatile unsigned long *) 0x40005800)) //I2C2 Control Reg 1
#define I2C2_CR2   (*((volatile unsigned long *) 0x40005804)) //I2C2 Control Reg 2
#define I2C2_OAR1  (*((volatile unsigned long *) 0x40005808)) //I2C2 Own Addr Reg 1
#define I2C2_OAR2  (*((volatile unsigned long *) 0x4000580C)) //I2C2 Own Addr Reg 2
#define I2C2_DR    (*((volatile unsigned long *) 0x40005810)) //I2C2 Data Reg
#define I2C2_SR1   (*((volatile unsigned long *) 0x40005814)) //I2C2 Status Reg 1
#define I2C2_SR2   (*((volatile unsigned long *) 0x40005818)) //I2C2 Status Reg 2
#define I2C2_CCR   (*((volatile unsigned long *) 0x4000581C)) //I2C2 Clock Control Reg
#define I2C2_TRISE (*((volatile unsigned long *) 0x40005820)) //I2C2 Rise Time Reg
#define I2C2_FLTR  (*((volatile unsigned long *) 0x40005824)) //I2C2 Filter Reg
//I2C3
#define I2C3_CR1   (*((volatile unsigned long *) 0x40005C00)) //I2C3 Control Reg 1
#define I2C3_CR2   (*((volatile unsigned long *) 0x40005C04)) //I2C3 Control Reg 2
#define I2C3_OAR1  (*((volatile unsigned long *) 0x40005C08)) //I2C3 Own Addr Reg 1
#define I2C3_OAR2  (*((volatile unsigned long *) 0x40005C0C)) //I2C3 Own Addr Reg 2
#define I2C3_DR    (*((volatile unsigned long *) 0x40005C10)) //I2C3 Data Reg
#define I2C3_SR1   (*((volatile unsigned long *) 0x40005C14)) //I2C3 Status Reg 1
#define I2C3_SR2   (*((volatile unsigned long *) 0x40005C18)) //I2C3 Status Reg 2
#define I2C3_CCR   (*((volatile unsigned long *) 0x40005C1C)) //I2C3 Clock Control Reg
#define I2C3_TRISE (*((volatile unsigned long *) 0x40005C20)) //I2C3 Rise Time Reg
#define I2C3_FLTR  (*((volatile unsigned long *) 0x40005C24)) //I2C3 Filter Reg
//SPI1
#define SPI1_CR1     (*((volatile unsigned long *) 0x40013000)) //SPI1 Control Reg 1
#define SPI1_CR2     (*((volatile unsigned long *) 0x40013004)) //SPI1 Control Reg 2
#define SPI1_SR      (*((volatile unsigned long *) 0x40013008)) //SPI1 Status Reg
#define SPI1_DR      (*((volatile unsigned long *) 0x4001300C)) //SPI1 Data Reg
#define SPI1_CRCPR   (*((volatile unsigned long *) 0x40013010)) //SPI1 CRC Polynomial Reg
#define SPI1_RXCRCR  (*((volatile unsigned long *) 0x40013014)) //SPI1 CRS receive
#define SPI1_TXCRCR  (*((volatile unsigned long *) 0x40013018)) //SPI1 CRC transmit
#define SPI1_I2SCFGR (*((volatile unsigned long *) 0x4001301C)) //SPI1 I2S Config Reg
#define SPI1_I2SCPR  (*((volatile unsigned long *) 0x40013020)) //SPI1 I2S Clk Prescale
//SPI2
#define SPI2_CR1     (*((volatile unsigned long *) 0x40003800)) //SPI2 Control Reg 1
#define SPI2_CR2     (*((volatile unsigned long *) 0x40003804)) //SPI2 Control Reg 2
#define SPI2_SR      (*((volatile unsigned long *) 0x40003808)) //SPI2 Status Reg
#define SPI2_DR      (*((volatile unsigned long *) 0x4000380C)) //SPI2 Data Reg
#define SPI2_CRCPR   (*((volatile unsigned long *) 0x40003810)) //SPI2 CRC Polynomial Reg
#define SPI2_RXCRCR  (*((volatile unsigned long *) 0x40003814)) //SPI2 CRS receive
#define SPI2_TXCRCR  (*((volatile unsigned long *) 0x40003818)) //SPI2 CRC transmit
#define SPI2_I2SCFGR (*((volatile unsigned long *) 0x4000381C)) //SPI2 I2S Config Reg
#define SPI2_I2SCPR  (*((volatile unsigned long *) 0x40003820)) //SPI2 I2S Clk Prescale
//SPI3
#define SPI3_CR1     (*((volatile unsigned long *) 0x40003C00)) //SPI3 Control Reg 1
#define SPI3_CR2     (*((volatile unsigned long *) 0x40003C04)) //SPI3 Control Reg 2
#define SPI3_SR      (*((volatile unsigned long *) 0x40003C08)) //SPI3 Status Reg
#define SPI3_DR      (*((volatile unsigned long *) 0x40003C0C)) //SPI3 Data Reg
#define SPI3_CRCPR   (*((volatile unsigned long *) 0x40003C10)) //SPI3 CRC Polynomial Reg
#define SPI3_RXCRCR  (*((volatile unsigned long *) 0x40003C14)) //SPI3 CRS receive
#define SPI3_TXCRCR  (*((volatile unsigned long *) 0x40003C18)) //SPI3 CRC transmit
#define SPI3_I2SCFGR (*((volatile unsigned long *) 0x40003C1C)) //SPI3 I2S Config Reg
#define SPI3_I2SCPR  (*((volatile unsigned long *) 0x40003C20)) //SPI3 I2S Clk Prescale





