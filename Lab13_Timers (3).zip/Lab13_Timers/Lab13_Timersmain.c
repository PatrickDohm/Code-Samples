// Lab13_Timersmain.c
// Runs on MSP432
// Student starter code for Timers lab
// Daniel and Jonathan Valvano
// July 11, 2019
// PWM output to motor
// Second Periodic interrupt


// Negative logic bump sensors
// P4.7 Bump5, left side of robot
// P4.6 Bump4
// P4.5 Bump3
// P4.3 Bump2
// P4.2 Bump1
// P4.0 Bump0, right side of robot

// Left motor direction connected to P5.4 (J3.29)
// Left motor PWM connected to P2.7/TA0CCP4 (J4.40)
// Left motor enable connected to P3.7 (J4.31)
// Right motor direction connected to P5.5 (J3.30)
// Right motor PWM connected to P2.6/TA0CCP3 (J4.39)
// Right motor enable connected to P3.6 (J2.11)

#include "msp.h"
#include "..\inc\bump.h"
#include "..\inc\Clock.h"
#include "..\inc\SysTick.h"
#include "..\inc\CortexM.h"
#include "..\inc\LaunchPad.h"
#include "..\inc\Motor.h"
#include "..\inc\TimerA1.h"
#include "..\inc\TExaS.h"
#include "..\inc\PWM.h"
#include "..\inc\Reflectance.h"
#include "..\inc\UART0.h"

enum scenario {
    Error=0,
    TeeJoint = 11,
    LeftJoint = 12,
    RightJoint = 13,
    CrossRoad = 14,

};

struct State {
  uint32_t LeftMotor;
  uint32_t RightMotor;
  uint32_t Time;           // 10 ms
  const struct State *Next[5];};
typedef const struct State State_t;
#define goStraight   &FSM[0]
#define waitStraight &FSM[1]
#define goLeft   &FSM[2]
#define waitLeft &FSM[3]
#define goRight &FSM[4]
#define waitRight &FSM[5]
State_t FSM[6]={
 {2000,2000,500,{waitStraight,waitStraight,waitStraight,waitStraight}},//go Straight
 {2000,2000,100000,{goStraight,goRight,goLeft,waitStraight}},//waitStraight
 {2150,0,1900,{waitLeft,waitLeft,waitLeft,waitLeft}},//goLeft
 {1050,1100, 800,{goStraight,goRight,goLeft,waitLeft}},//waitLeft
 {0,2150, 1900,{waitRight,waitRight,waitRight,waitRight}},//goRight
 {1100,1100, 700, {goStraight,goRight,goLeft,waitRight}}//waitRight
};

// Driver test
void TimedPause(uint32_t time){
  Clock_Delay1ms(time);          // run for a while and stop
  Motor_Stop();
  while(LaunchPad_Input()==0);  // wait for touch
  while(LaunchPad_Input());     // wait for release
}
int Program13_1(void){
  Clock_Init48MHz();
  LaunchPad_Init(); // built-in switches and LEDs
  Bump_Init();      // bump switches
  Motor_Init();     // your function
  while(1){
    TimedPause(4000);
    Motor_Forward(7500,7500);  // your function
    TimedPause(2000);
    Motor_Backward(7500,7500); // your function
    TimedPause(3000);
    Motor_Left(5000,5000);     // your function
    TimedPause(3000);
    Motor_Right(5000,5000);    // your function
  }
}

// Test of Periodic interrupt
#define REDLED (*((volatile uint8_t *)(0x42098060)))
#define BLUELED (*((volatile uint8_t *)(0x42098068)))
uint32_t Time;
void Task(void){
  REDLED ^= 0x01;       // toggle P2.0
  REDLED ^= 0x01;       // toggle P2.0
  Time = Time + 1;
  REDLED ^= 0x01;       // toggle P2.0
}
int Program13_2(void){
  Clock_Init48MHz();
  LaunchPad_Init();  // built-in switches and LEDs
  TimerA1_Init(&Task,500);  // 1000 Hz
  EnableInterrupts();
  while(1){
    BLUELED ^= 0x01; // toggle P2.1
  }
}
//Bump_Read(void);


uint8_t bumpSensorResult;
uint8_t newBumpData=0;
int32_t lineSensorResult=0;
int32_t rawLineSensorData=0;
uint8_t newLineData=0;
void SysTick_Handler(void){
    static int count=0;
    uint8_t tempBump=0;
    if(count==0){
        Reflectance_Start();
        tempBump=Bump_Read();
        if(tempBump != bumpSensorResult){
            bumpSensorResult=tempBump;
            if(tempBump!=0){
                newBumpData=1;
            }
        }
    }else if(count==1){
        rawLineSensorData=Reflectance_End();
        lineSensorResult=Reflectance_Position(rawLineSensorData);
        newLineData=1;

    }
    count++;
    if(count>10){
        count=0;
    }
}

void SysTick_Init1(uint32_t period, uint32_t priority){
  SysTick->CTRL = 0;              // 1) disable SysTick during setup
  SysTick->LOAD = period - 1;     // 2) reload value sets period
  SysTick->VAL = 0;               // 3) any write to current clears it
  SCB->SHP[11] = priority<<5;     // set priority into top 3 bits of 8-bit register
  SysTick->CTRL = 0x00000007;     // 4) enable SysTick with core clock and interrupts
}


int dutyCycles [5]={0,1000, 3000, 6000, 10000};
enum scenario Classify(uint32_t rawLineSensorData ){
  enum scenario result=Error;
  Clock_Delay1ms(50);
  if(rawLineSensorData ==0xFF){
      result=TeeJoint;
  }else if(rawLineSensorData <6){
      result=RightJoint;
  }else if(rawLineSensorData >230){
      result=LeftJoint;
  }

  return result;
}

#define KP 10
int main(void){
    // write a main program that uses PWM to move the robot
    // like Program13_1, but uses TimerA1 to periodically
    // check the bump switches, stopping the robot on a collision
    Clock_Init48MHz();
    UART0_Init();
    LaunchPad_Init();  // built-in switches and LEDs
    SysTick_Init1(48000,3);
    PWM_Init34(15000, 1000, 1000);
    Bump_Init();
    Reflectance_Init();
    State_t *pt;      // state pointer
    pt = goStraight;
    int numberofIntersections=1;
    enum scenario result=Error;

  while(1){


      if(newBumpData){
          while(bumpSensorResult>0){

            TIMER_A0->CCR[3]=0;   //if bump stop, else go
            TIMER_A0->CCR[4]=0;
            newBumpData=0;
          }
      }
      if(newLineData){//3 is left, 4 is right

              result=Classify(rawLineSensorData);
              newLineData=0;
              }
      if(pt==goStraight){
              Clock_Delay1ms(pt->Time);
              pt=pt->Next[1];
          }
      else if(pt==waitStraight){
          TIMER_A0->CCR[3]=pt->LeftMotor - (KP * lineSensorResult);
          TIMER_A0->CCR[4]=pt->RightMotor + (KP * lineSensorResult);

          if(result== TeeJoint || result== RightJoint || result == LeftJoint){//if all the sensors are covered
              UART0_OutString("Number of intersections= ");
              UART0_OutUDec(numberofIntersections);
              UART0_OutString("\r\n ");
              if(numberofIntersections==1){

                  pt=pt->Next[0];//go straight on first intersection
              }else if(numberofIntersections==2){

                  pt=pt->Next[1];//go right on second intersection
              }else if(numberofIntersections==3){

                  pt=pt->Next[2];//go left on third intersection
              }else if(numberofIntersections==4){

                  pt=pt->Next[2];//go left on fourth intersection
              }else if(numberofIntersections==5){

                  pt=pt->Next[1];//go right on fifth intersection
              }else if(numberofIntersections==6 || numberofIntersections==7 ||numberofIntersections==8 ){//some trick turns at end

                  pt=pt->Next[0];//go straight on last intersection
              }else{
                  TIMER_A0->CCR[3]=0;   //stop at end
                  TIMER_A0->CCR[4]=0;
                  Clock_Delay1ms(pt->Time);
              }
              numberofIntersections++;
          }else{
              pt=pt->Next[3];//no intersection, keep going straight
          }
      }else if(pt==goRight){
          TIMER_A0->CCR[3]=pt->LeftMotor;
          TIMER_A0->CCR[4]=pt->RightMotor;
          Clock_Delay1ms(pt->Time);
          pt=pt->Next[0];
      }else if(pt==waitRight){
          TIMER_A0->CCR[3]=pt->LeftMotor;
          TIMER_A0->CCR[4]=pt->RightMotor;
          Clock_Delay1ms(pt->Time);
          pt=pt->Next[0];
      }else if(pt==goLeft){
          TIMER_A0->CCR[3]=pt->LeftMotor;
          TIMER_A0->CCR[4]=pt->RightMotor;
          Clock_Delay1ms(pt->Time);
          pt=pt->Next[0];
      }else if(pt==waitLeft){
          TIMER_A0->CCR[3]=pt->LeftMotor;
          TIMER_A0->CCR[4]=pt->RightMotor;
          Clock_Delay1ms(pt->Time);
          pt=pt->Next[0];
      }



}

  }


